"use client";

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useRole } from '../../../hooks/useRole';
import { API_ENDPOINTS } from '../../../config/api';
import MapLocationPicker from '../../../components/ui/MapLocationPicker';

export default function ExpertProfilePage() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [targetUserId, setTargetUserId] = useState(null);
  const [targetUser, setTargetUser] = useState(null);
  const [formData, setFormData] = useState({
    bio: '',
    experience: '',
    basePrice: '',
    location: '',
    locationData: null, // { lat, lng, address, displayName }
    isShop: false,
    isMobile: true,
    shopInfo: {
      name: '',
      description: '',
      phone: '',
      address: '',
      locationData: null // { lat, lng, address, displayName }
    }
  });
  const userRole = useRole();
  const searchParams = useSearchParams();

  useEffect(() => {
    // دریافت userId از URL
    const userId = searchParams.get('userId');
    setTargetUserId(userId);
    if (userId) {
      fetchUserData(userId);
    }
    fetchProfileData(userId);
  }, [searchParams]);

  const fetchUserData = async (userId) => {
    try {
      const response = await fetch(API_ENDPOINTS.users.getById(userId), {
        credentials: 'include'
      });
      
      if (response.ok) {
        const userData = await response.json();
        if (userData.success) {
          setTargetUser(userData.data);
        }
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const fetchProfileData = async (userId = null) => {
    try {
      setLoading(true);
      
      let profileUrl = `${API_ENDPOINTS.experts.base}/profile/current`;
      if (userId) {
        // اگر userId مشخص شده، از API جدید استفاده کن
        profileUrl = `${API_ENDPOINTS.experts.getUserProfile}?userId=${userId}`;
      }
      
      const response = await fetch(profileUrl, {
        credentials: 'include'
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success && result.data) {
          setProfile(result.data);
          setFormData({
            bio: result.data.bio || '',
            experience: result.data.experience || '',
            basePrice: result.data.basePrice || '',
            location: result.data.location || '',
            locationData: result.data.locationData || null,
            isShop: result.data.isShop || false,
            isMobile: result.data.isMobile !== undefined ? result.data.isMobile : true,
            shopInfo: {
              name: result.data.shopInfo?.name || '',
              description: result.data.shopInfo?.description || '',
              phone: result.data.shopInfo?.phone || '',
              address: result.data.shopInfo?.address || '',
              locationData: result.data.shopInfo?.locationData || null
            }
          });
        }
      } else if (response.status === 404) {
        // Expert profile doesn't exist yet, show empty form
        setProfile(null);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name.startsWith('shopInfo.')) {
      const shopField = name.split('.')[1];
      setFormData(prev => ({
        ...prev,
        shopInfo: {
          ...prev.shopInfo,
          [shopField]: type === 'checkbox' ? checked : value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }
  };

  const handleLocationSelect = (locationData) => {
    setFormData(prev => ({
      ...prev,
      locationData
    }));
  };

  const handleShopLocationSelect = (locationData) => {
    setFormData(prev => ({
      ...prev,
      shopInfo: {
        ...prev.shopInfo,
        locationData
      }
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      
      let updateUrl = `${API_ENDPOINTS.experts.base}/profile/current`;
      let requestBody = formData;
      
      if (targetUserId) {
        // اگر userId مشخص شده، از API جدید استفاده کن
        updateUrl = `${API_ENDPOINTS.experts.base}/${targetUserId}`;
        requestBody = {
          ...formData,
          userId: targetUserId
        };
      }
      
      const response = await fetch(updateUrl, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(requestBody)
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          alert('پروفایل با موفقیت بروزرسانی شد');
          fetchProfileData(targetUserId); // Refresh data
        } else {
          alert('خطا در بروزرسانی پروفایل: ' + result.message);
        }
      } else {
        alert('خطا در بروزرسانی پروفایل');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('خطا در بروزرسانی پروفایل');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">
          {targetUserId ? (
            targetUser ? 
              `ویرایش پروفایل متخصص ${targetUser.firstName} ${targetUser.lastName}` :
              `ویرایش پروفایل متخصص (ID: ${targetUserId})`
          ) : 'ویرایش پروفایل متخصص'}
        </h1>
        
        {profile && (
          <div className="mb-6 p-4 bg-blue-50 rounded-lg">
            <h2 className="text-lg font-semibold text-blue-900 mb-2">اطلاعات کاربر</h2>
            <p className="text-blue-700">
              {profile.user?.firstName} {profile.user?.lastName} ({profile.user?.email})
            </p>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                بیوگرافی
              </label>
              <textarea
                name="bio"
                value={formData.bio}
                onChange={handleInputChange}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="درباره خود و تخصص‌هایتان بنویسید"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                تجربه (سال)
              </label>
              <input
                type="text"
                name="experience"
                value={formData.experience}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="مثال: 5 سال"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                قیمت پایه (تومان)
              </label>
              <input
                type="number"
                name="basePrice"
                value={formData.basePrice}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="قیمت پایه خدمات"
              />
            </div>
            
                         <div className="md:col-span-2">
               <label className="block text-sm font-medium text-gray-700 mb-2">
                 موقعیت مکانی
               </label>
               <input
                 type="text"
                 name="location"
                 value={formData.location}
                 onChange={handleInputChange}
                 className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                 placeholder="شهر یا منطقه (اختیاری)"
               />
               
               <div className="mb-4">
                 <label className="block text-sm font-medium text-gray-700 mb-2">
                   انتخاب موقعیت دقیق روی نقشه
                 </label>
                 <MapLocationPicker
                   onLocationSelect={handleLocationSelect}
                   initialLocation={formData.locationData}
                   placeholder="روی نقشه کلیک کنید تا موقعیت دقیق خود را انتخاب کنید"
                   height="300px"
                 />
               </div>
             </div>
            
                         <div className="md:col-span-2">
               <div className="space-y-4">
                 <div className="flex items-center">
                   <input
                     type="checkbox"
                     name="isShop"
                     checked={formData.isShop}
                     onChange={handleInputChange}
                     className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                   />
                   <label className="mr-2 block text-sm text-gray-900">
                     دارای مغازه
                   </label>
                 </div>
                 
                 <div className="flex items-center">
                   <input
                     type="checkbox"
                     name="isMobile"
                     checked={formData.isMobile}
                     onChange={handleInputChange}
                     className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                   />
                   <label className="mr-2 block text-sm text-gray-900">
                     اعزام به محل
                   </label>
                 </div>
               </div>
             </div>

             {/* Shop Information Section */}
             {formData.isShop && (
               <div className="md:col-span-2">
                 <div className="border-t border-gray-200 pt-6">
                   <h3 className="text-lg font-medium text-gray-900 mb-4">اطلاعات مغازه</h3>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="md:col-span-2">
                       <label className="block text-sm font-medium text-gray-700 mb-2">
                         نام مغازه
                       </label>
                       <input
                         type="text"
                         name="shopInfo.name"
                         value={formData.shopInfo.name}
                         onChange={handleInputChange}
                         className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                         placeholder="نام مغازه خود را وارد کنید"
                       />
                     </div>
                     
                     <div className="md:col-span-2">
                       <label className="block text-sm font-medium text-gray-700 mb-2">
                         توضیحات مغازه
                       </label>
                       <textarea
                         name="shopInfo.description"
                         value={formData.shopInfo.description}
                         onChange={handleInputChange}
                         rows={3}
                         className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                         placeholder="توضیحات کوتاه درباره مغازه"
                       />
                     </div>
                     
                     <div>
                       <label className="block text-sm font-medium text-gray-700 mb-2">
                         تلفن مغازه
                       </label>
                       <input
                         type="tel"
                         name="shopInfo.phone"
                         value={formData.shopInfo.phone}
                         onChange={handleInputChange}
                         className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                         placeholder="شماره تلفن مغازه"
                       />
                     </div>
                     
                     <div>
                       <label className="block text-sm font-medium text-gray-700 mb-2">
                         آدرس مغازه
                       </label>
                       <input
                         type="text"
                         name="shopInfo.address"
                         value={formData.shopInfo.address}
                         onChange={handleInputChange}
                         className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                         placeholder="آدرس کامل مغازه"
                       />
                     </div>
                     
                     <div className="md:col-span-2">
                       <label className="block text-sm font-medium text-gray-700 mb-2">
                         موقعیت مغازه روی نقشه
                       </label>
                       <MapLocationPicker
                         onLocationSelect={handleShopLocationSelect}
                         initialLocation={formData.shopInfo.locationData}
                         placeholder="روی نقشه کلیک کنید تا موقعیت مغازه را انتخاب کنید"
                         height="300px"
                       />
                     </div>
                   </div>
                 </div>
               </div>
             )}
          </div>
          
          <div className="mt-6 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
