"use client";

import { useState, useEffect } from 'react';
import { useRole } from '../../../hooks/useRole';
import { API_ENDPOINTS } from '../../../config/api';
import UserAvatar from '../../../components/ui/UserAvatar';
import Link from 'next/link';

export default function UserProfilePage() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const userRole = useRole();

  const tabs = [
    { 
      id: 'personal-display', 
      label: 'نمایش شخصی', 
      icon: '👤',
      href: '/dashboard/user/personal-display',
      description: 'مشاهده اطلاعات شخصی شما'
    },
    { 
      id: 'personal-edit', 
      label: 'ویرایش شخصی', 
      icon: '✏️',
      href: '/dashboard/user/personal-edit',
      description: 'ویرایش اطلاعات شخصی'
    },
    { 
      id: 'professional-display', 
      label: 'نمایش تخصصی', 
      icon: '💼',
      href: '/dashboard/user/professional-display',
      description: 'مشاهده اطلاعات تخصصی و حرفه‌ای'
    },
    { 
      id: 'professional-edit', 
      label: 'ویرایش تخصصی', 
      icon: '🔧',
      href: '/dashboard/user/professional-edit',
      description: 'ویرایش اطلاعات تخصصی'
    }
  ];

  useEffect(() => {
    fetchProfileData();
  }, []);

  const fetchProfileData = async () => {
    try {
      setLoading(true);
      const response = await fetch(API_ENDPOINTS.users.getCurrentProfile, {
        credentials: 'include'
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success && result.data) {
          setProfile(result.data);
        }
      } else if (response.status === 404) {
        setProfile(null);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">پروفایل کاربری</h1>
          {profile && (
            <div className="flex items-center space-x-4 space-x-reverse">
              <UserAvatar 
                user={profile} 
                size="md" 
                className="rounded-full border border-gray-300" 
              />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {profile.firstName} {profile.lastName}
                </h3>
                <p className="text-gray-600 text-sm">{profile.email}</p>
              </div>
            </div>
          )}
        </div>
        
        <p className="text-gray-600">
          برای مدیریت اطلاعات شخصی و تخصصی خود، یکی از گزینه‌های زیر را انتخاب کنید.
        </p>
      </div>

      {/* Navigation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {tabs.map((tab) => (
          <Link
            key={tab.id}
            href={tab.href}
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow duration-200 border border-gray-200 hover:border-blue-300 group"
          >
            <div className="flex items-start space-x-4 space-x-reverse">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                  <span className="text-2xl">{tab.icon}</span>
                </div>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {tab.label}
                </h3>
                <p className="text-gray-600 text-sm">
                  {tab.description}
                </p>
                <div className="mt-4 flex items-center text-blue-600 text-sm font-medium">
                  <span>مشاهده</span>
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Quick Stats */}
      {profile && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">خلاصه وضعیت</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">وضعیت حساب</span>
                <span className={`px-2 py-1 rounded text-xs ${profile.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {profile.isActive ? 'فعال' : 'غیرفعال'}
                </span>
              </div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">تأیید ایمیل</span>
                <span className={`px-2 py-1 rounded text-xs ${profile.isEmailVerified ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {profile.isEmailVerified ? 'تأیید شده' : 'تأیید نشده'}
                </span>
              </div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">تأیید موبایل</span>
                <span className={`px-2 py-1 rounded text-xs ${profile.isMobileVerified ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {profile.isMobileVerified ? 'تأیید شده' : 'تأیید نشده'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
