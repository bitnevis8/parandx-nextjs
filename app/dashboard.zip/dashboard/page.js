"use client";

import { useState } from 'react';
import { useRole } from '../hooks/useRole';
import Link from 'next/link';

export default function DashboardPage() {
  const userRole = useRole();
  const { user, getPrimaryRole } = userRole;
  const [activeTab, setActiveTab] = useState('profile');

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">دسترسی غیرمجاز</h1>
          <p className="text-gray-600">لطفا ابتدا وارد شوید</p>
        </div>
      </div>
    );
  }

  const primaryRole = getPrimaryRole();
  const userRoles = userRole.getUserRoles();

  const getRoleDisplayName = (role) => {
    switch (role) {
      case 'admin': return 'مدیر کل';
      case 'moderator': return 'ناظر';
      case 'expert': return 'متخصص';
      case 'customer': return 'مشتری';
      default: return role;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">خوش آمدید به داشبورد</h2>
          <p className="text-gray-600">
            از منوی سمت راست می‌توانید به بخش‌های مختلف دسترسی پیدا کنید.
          </p>
        </div>
      </div>
    </div>
  );
}