'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useRole } from '../../hooks/useRole';
import { 
  BuildingOffice2Icon as WarehouseIcon,
  CubeIcon as PackageIcon,
  ClipboardDocumentListIcon as ClipboardListIcon,
  UserPlusIcon
} from '@heroicons/react/24/outline';

// منوهای مختلف بر اساس نقش
const getMenuItems = (userRole) => {
  const baseItems = [
    {
      title: 'داشبورد',
      path: '/dashboard',
      icon: '🏠',
    }
  ];

  // منوهای مدیریت (فقط برای مدیران و ناظران)
  if (userRole.canAccessAdmin()) {
    baseItems.push({
      title: 'مدیریت کاربران',
      icon: '👤',
      submenu: [
        { title: 'لیست کاربران', path: '/dashboard/user-management/users', icon: '🧑‍💼' },
        { title: 'لیست نقش‌ها', path: '/dashboard/user-management/roles', icon: '🛡️' },
      ],
    });
  }

  // منوهای پروفایل کاربر (برای همه کاربران)
  baseItems.push({
    title: 'پروفایل کاربری',
    icon: '👤',
    submenu: [
      { title: 'ویرایش پروفایل', path: '/dashboard/user/profile', icon: '✏️' },
    ],
  });

  // منوهای متخصص (برای متخصصان، مدیران و ناظران)
  if (userRole.canAccessExpert()) {
    baseItems.push({
      title: 'پروفایل متخصص',
      icon: '🔧',
      submenu: [
        { title: 'ویرایش پروفایل', path: '/dashboard/expert/profile', icon: '✏️' },
        { title: 'تخصص‌ها', path: '/dashboard/expert/specializations', icon: '🎯' },
        { title: 'درخواست‌ها', path: '/dashboard/expert/requests', icon: '📋' },
        { title: 'نظرات', path: '/dashboard/expert/reviews', icon: '⭐' },
      ],
    });
  }

  // منوهای مشتری (برای همه کاربران)
  if (userRole.canAccessCustomer()) {
    baseItems.push({
      title: 'درخواست‌های من',
      icon: '📝',
      submenu: [
        { title: 'درخواست‌های جدید', path: '/dashboard/customer/new-request', icon: '➕' },
        { title: 'درخواست‌های فعال', path: '/dashboard/customer/active-requests', icon: '🔄' },
        { title: 'تاریخچه', path: '/dashboard/customer/history', icon: '📊' },
        { title: 'نظرات من', path: '/dashboard/customer/my-reviews', icon: '💬' },
      ],
    });
  }

  // منوهای تنظیمات (فقط برای مدیران و ناظران)
  if (userRole.canAccessAdmin()) {
    baseItems.push({
      title: 'تنظیمات',
      icon: '⚙️',
      submenu: [
        { title: 'مدیریت مراکز', path: '/dashboard/settings/unit-locations', icon: '📍' },
        { title: 'مدیریت نرخ‌ها', path: '/dashboard/settings/rate-settings', icon: '💰' },
      ],
    });
  }

  return baseItems;
};

export default function Sidebar({ onLinkClick }) {
  const pathname = usePathname();
  const [openMenu, setOpenMenu] = useState(null);
  const userRole = useRole();
  
  const menuItems = getMenuItems(userRole);

  const toggleMenu = (title) => {
    setOpenMenu(openMenu === title ? null : title);
  };

  const isActive = (path) => {
    return pathname === path || pathname.startsWith(path + '/');
  };

  return (
    <aside className="w-64 h-screen bg-white text-gray-800 p-4 shadow-xl border-l border-gray-200">
      {/* داشبورد در بالای سایدبار */}
      <div className="mb-6">
        <Link
          href="/dashboard"
          onClick={onLinkClick}
          className={`flex items-center p-3 rounded-lg hover:bg-blue-50 transition-colors ${
            isActive('/dashboard') ? 'bg-blue-100 text-blue-700' : ''
          }`}
        >
          <span className="ml-2 text-xl">🏠</span>
          <span className="text-lg font-semibold">داشبورد</span>
        </Link>
      </div>
      
      <nav className="space-y-2">
        {menuItems.filter(item => item.path !== '/dashboard').map((item) => (
          <div key={item.title} className="space-y-1">
            {item.submenu ? (
              <div>
                <button
                  onClick={() => toggleMenu(item.title)}
                  className={`w-full flex items-center justify-between p-2 rounded-lg hover:bg-blue-50 transition-colors ${
                    openMenu === item.title ? 'bg-blue-100 text-blue-700' : ''
                  }`}
                >
                  <div className="flex items-center">
                    <span className="ml-2">{item.icon}</span>
                    <span>{item.title}</span>
                  </div>
                  <span className="text-lg">
                    {openMenu === item.title ? '▼' : '▶'}
                  </span>
                </button>
                
                {openMenu === item.title && (
                  <div className="mr-4 mt-1 space-y-1">
                    {item.submenu.map((subItem) => (
                      <Link
                        key={subItem.path}
                        href={subItem.path}
                        onClick={onLinkClick}
                        className={`flex items-center p-2 rounded-lg hover:bg-blue-50 transition-colors ${
                          isActive(subItem.path) ? 'bg-blue-100 text-blue-700' : ''
                        }`}
                      >
                        <span className="ml-2">{subItem.icon}</span>
                        <span>{subItem.title}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <Link
                href={item.path}
                onClick={onLinkClick}
                className={`flex items-center p-2 rounded-lg hover:bg-blue-50 transition-colors ${
                  isActive(item.path) ? 'bg-blue-100 text-blue-700' : ''
                }`}
              >
                <span className="ml-2">{item.icon}</span>
                <span>{item.title}</span>
              </Link>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
} 