"use client";

import { useRole } from '../../hooks/useRole';

export default function ProfileDisplay() {
  const userRole = useRole();
  const { user } = userRole;

  if (!user) {
    return null;
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">نمایش نمایه شخصی</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">نام</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{user.firstName}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">نام خانوادگی</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{user.lastName}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">ایمیل</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{user.email}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">موبایل</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{user.mobile || 'نامشخص'}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">نام کاربری</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{user.username}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">وضعیت</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">
            {user.isActive ? 'فعال' : 'غیرفعال'}
          </p>
        </div>
      </div>
    </div>
  );
}
