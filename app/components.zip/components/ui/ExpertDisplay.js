"use client";

import { useRole } from '../../hooks/useRole';

export default function ExpertDisplay() {
  const userRole = useRole();
  const { user, getUserRoles } = userRole;

  if (!user) {
    return null;
  }

  const userRoles = getUserRoles();

  const getRoleDisplayName = (role) => {
    switch (role) {
      case 'admin': return 'مدیر کل';
      case 'moderator': return 'ناظر';
      case 'expert': return 'متخصص';
      case 'customer': return 'مشتری';
      default: return role;
    }
  };

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">نمایش نمایه تخصصی</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">نقش‌ها</label>
          <div className="flex flex-wrap gap-2">
            {userRoles.map((role, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
              >
                {getRoleDisplayName(role)}
              </span>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ عضویت</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">
            {user.createdAt ? new Date(user.createdAt).toLocaleDateString('fa-IR') : 'نامشخص'}
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">آخرین ورود</label>
          <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">
            {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleDateString('fa-IR') : 'نامشخص'}
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">وضعیت تأیید ایمیل</label>
          <p className={`p-3 rounded-lg ${user.isEmailVerified ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
            {user.isEmailVerified ? 'تأیید شده' : 'تأیید نشده'}
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">وضعیت تأیید موبایل</label>
          <p className={`p-3 rounded-lg ${user.isMobileVerified ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
            {user.isMobileVerified ? 'تأیید شده' : 'تأیید نشده'}
          </p>
        </div>
      </div>
    </div>
  );
}
